# README #

## Group: ##
Carlos Rijo - 1101626

João Fernades - 1221973

## Instructions for using the interpreter

### How to Use the Interpreter

1. Open the Python script containing the interpreter.

2. Locate the section where the program is defined ( bottom of the script).

3. Modify the `programs` array to include your desired commands. For example:

    ```python
    programs = [
        'load 2 r1',
        'add r1 r2',
        'store r1 5',
        'halt'
    ]
    ```

4. Save the changes to the script.

5. Run the Python script.

6. The interpreter will process the commands and execute the program.
