class ApooInterpreter:
    def __init__(self):
        self.initial_state = None
        self.final_state = None
        self.rules_applied = []
        self.pc = 0
        self.subroutine_stack = []
        self.regs = {}  # dictionary where we store the register names (like r1) and the value of the register that we store on it.
        #self.regs = {'r1':1,'r2':2,'r3':0,'r4':0,'r5':0,'r6':0}
        self.rs = -1  # last position of the regs stack
        self.rf = 0  # represents the base of the regs stack
        self.ra = 0  # Represents the currently used reg
        self.memory = {0:[],1:[],2:["r2",20],3:[],4:[],5:[],6:[],7:[],8:[],9:[]}  # This dictionary maps each memory address to its corresponding value. So we store the regs here.

    def interpret(self, program):
        try:
            self.initial_state = program
            self.final_state = self.apply_rules(program)
            return self.initial_state, self.final_state, self.rules_applied, self.pc
        except StopIteration:
            self.final_state = "HALT"
            return self.initial_state, self.final_state, self.rules_applied, self.pc

    def apply_rules(self, state):
        instruction, *args = state.split()

        if instruction == 'add':
            return self.apply_add_rule(*args)
        elif instruction == 'storeo':
            return self.apply_storeo_rule(*args)
        elif instruction == 'push':
            return self.apply_push_rule(*args)
        elif instruction == 'pop':
            return self.apply_pop_rule(*args)
        elif instruction == 'loado':
            return self.apply_loado_rule(*args)
        elif instruction == 'store':
            return self.apply_store_rule(*args)
        elif instruction == 'jump':
            return self.apply_jump_rule(*args)
        elif instruction == 'load':
            return self.apply_load_rule(*args)
        elif instruction == 'inc':
            return self.apply_inc_rule(*args)
        elif instruction == 'dec':
            return self.apply_dec_rule(*args)
        elif instruction == 'jsr':
            return self.apply_jsr_rule(*args)
        elif instruction == 'rtn':
            return self.apply_rtn_rule()
        elif instruction == 'halt':
            return self.apply_halt_rule()
        elif instruction == 'loadn':
            return self.apply_loadn_rule(*args)
        elif instruction == 'loadi':
            return self.apply_loadi_rule(*args)
        elif instruction == 'storer':
            return self.apply_storer_rule(*args)
        elif instruction == 'storei':
            return self.apply_storei_rule(*args)
        else:
            return state

############################ LOAD ####################################### DONE###################
    def apply_load_rule(self, mem_addr, ri):

        
        if not mem_addr.isdigit():
            raise ValueError("Invalid value for mem_addr.")
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        
        for key, value in self.memory.items():
            if value:
                self.regs[ri] = value[1]

        self.rules_applied.append(f'Rule: load {mem_addr} {ri} -> {ri} := mem[{mem_addr}]')
        self.pc += 1  # Increment the program counter
        return f'{ri} := mem[{mem_addr}]'
        
##################### ADD RULE########################################## DONE###################
    def apply_add_rule(self, ri, rj):
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        if not rj.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for rj.")
        
        self.regs[rj] = self.regs[ri] + self.regs[rj]
        #print(self.regs[rj])

        self.rules_applied.append(f'Rule: add {ri} {rj} -> {self.regs[rj]}')
        self.pc += 1
        return str(self.regs[rj])

##################### SUB RULE########################################## DONE###################
    def apply_sub_rule(self, ri, rj):
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        if not rj.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for rj.")
        
        self.regs[rj] = self.regs[ri] - self.regs[rj]
        print(self.regs[rj])

        self.rules_applied.append(f'Rule: sub {ri} {rj} -> {self.regs[rj]}')
        self.pc += 1
        return str(self.regs[rj])

##################### MUL RULE########################################## DONE###################
    def apply_mul_rule(self, ri, rj):
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        if not rj.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for rj.")
        
        self.regs[rj] = self.regs[ri] * self.regs[rj]
        print(self.regs[rj])

        self.rules_applied.append(f'Rule: mul {ri} {rj} -> {self.regs[rj]}')
        self.pc += 1
        return str(self.regs[rj])

##################### DIV RULE########################################## DONE###################
    def apply_div_rule(self, ri, rj):
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        if not rj.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for rj.")
        
        if rj == 0:
             raise ValueError("rj cant be zero")
        else:
            self.regs[rj] = self.regs[ri] + self.regs[rj]
        print(self.regs[rj])

        self.rules_applied.append(f'Rule: div {ri} {rj} -> {self.regs[rj]}')
        self.pc += 1
        return str(self.regs[rj])

##################### MOD RULE########################################## DONE###################
    def apply_mod_rule(self, ri, rj):
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        if not rj.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for rj.")
        
        if rj == 0:
            raise ValueError("rj cant be zero")
        else:
            self.regs[rj] = self.regs[ri] % self.regs[rj]
            print(self.regs[rj])

        self.rules_applied.append(f'Rule: mod {ri} {rj} -> {self.regs[rj]}')
        self.pc += 1
        return str(self.regs[rj])

##################### STORE RULE########################################## DONE ###################
    def apply_store_rule(self, ri, mem_addr):
        #print ("in store rule")

        if not mem_addr.isdigit():
            raise ValueError("Invalid value for mem_addr.")
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        
        for key, value in self.regs.items():
            if key == ri :
                self.memory[int(mem_addr)] = value
                break
        
        self.rules_applied.append(f'Rule: store {ri} {int(mem_addr)} -> mem[{int(mem_addr)}] := {ri}')
        self.pc += 1  # Increment the program counter
        return f'mem[{int(mem_addr)}] := {ri}'
##################### inc RULE########################################## DONE ###################
    def apply_inc_rule(self, ri):
        # Verify that ri is a valid register value
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        
        for keys, value in self.regs.items():
            if keys == ri:
                self.regs[ri] += 1

        self.rules_applied.append(f'Rule: dec {ri} -> {ri} := {ri} + 1')
        self.pc += 1  # Increment the program counter
        return f'{ri} := {ri} + 1'
##################### dec RULE########################################## DONE ###################
    def apply_dec_rule(self, ri):
        # Verify that ri is a valid register value
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")

        for keys, value in self.regs.items():
            if keys == ri:
                self.regs[ri] -= 1

        self.rules_applied.append(f'Rule: dec {ri} -> {ri} := {ri} - 1')
        self.pc += 1  # Increment the program counter
        return f'{ri} := {ri} - 1'

##################### JSR RULE########################################## DONE ###################
    def apply_jsr_rule(self, addr):
        self.pc += 1
        self.old_pc = self.pc
        for index, string in enumerate(programs):
            if string.startswith(addr):
                match = string.replace(addr+": ", "")
                self.pc = int(index)
                break
       
        self.rules_applied.append(f'Rule: jsr {addr} -> mem[rs + 1] := pc, rs + 1, pc := mem[{addr}]')
        self.subroutine_stack.append(self.pc + 1)  # Save the return address
        return f'mem[rs + 1] := pc, rs + 1, pc := mem[{addr}]'

    def apply_storeo_rule(self, ri, num):
        if not ri in self.regs:
            raise ValueError("Invalid register value for ri.")
        if not num.isdigit():
            raise ValueError("Invalid value for num.")

        mem_addr = self.rf + int(num)
        self.rules_applied.append(f'Rule: storeo {ri} {num} -> mem[{mem_addr}] := {ri}')
        self.pc += 1
        return f'mem[{mem_addr}] := {ri}'
 ##################### PUSH RULE########################################## DONE ###################
    def apply_push_rule(self, ri):
        #print ("in push rule")

        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        reg_available = 1 
        for key, value in self.regs.items():
            if key == ri :
                #print("Cant push an existing value")
                reg_available = 0 
                break
            
        if reg_available == 1:
            #print("A")
            self.regs.update({ri:0})
            self.rs +=1
 
        self.rules_applied.append(f'Rule: push {ri} -> mem[rs] := regs[{ri}], rs +1')
        self.pc += 1
        return f'mem[rs] := regs[{ri}], rs + 1'
 ##################### POP RULE########################################## DONE ###################
    def apply_pop_rule(self, ri):
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        for key, value in self.regs.items():
            if key == ri :
                self.regs.pop(ri) 
                self.rs -=1
                break
 
        self.rules_applied.append(f'Rule: pop {ri} -> regs[{ri}] := mem[rs], rs -1')
        self.pc += 1
        return f'mem[rs] := regs[{ri}], rs - 1'

    def apply_loado_rule(self, num, ri):
    
        if not num.isdigit():
            raise ValueError("Invalid value for num.")
            
            
        self.ra = None
        if self.rf < 0:
            raise ValueError("Invalid memory address.")
        if self.rs == -1:
            raise ValueError("Invalid memory address.")
            #break
        else:
            self.ra = self.rf+num
            if self.rs < self.ra:
                raise ValueError("Invalid memory address.")
                #break
            
            #else:
                
            for key, value in self.memory.items():
                #print("entered loop")
                #print(str(key))
                #print (value)
                if ri in self.memory:
                    #print("entered if")
                    self.ra = self.ri
                    #print(f"The Value for ri is{ri} and the value stored is{value}")
                    break  # Exit the loop if a match is found
        if self.ra is not None:
            self.memory,update = self.ra+num
            #print(self.rf , self.memory[self.ra])
            self.rules_applied.append(f'Rule: loado {ri} {num} -> {ri} := mem[{self.memory[self.ra]}]')
            self.pc += 1
            
        else:
            self.ra = self.rf + 1
            self.memory[ri] = self.rf
            #print(self.rf , self.memory[self.ra])
            self.rules_applied.append(f'Rule: loado {ri} {num} -> {ri} := mem[{self.memory[self.ra]}]')
            self.pc += 1
            
        #print(self.memory.items())
        #print ("getting out")
        return f'{ri} := mem[{self.memory[self.ra]}]'
 ##################### JUMP RULE########################################## DONE ###################
    def apply_jump_rule(self, addr):
        self.old_pc = self.pc
        for index, string in enumerate(programs):
            if string.startswith(addr):
                match = string.replace(addr+": ", "")
                self.pc = int(index)
                break
       
        self.rules_applied.append(f'Rule: jsr {addr} -> mem[rs + 1] := pc, rs + 1, pc := mem[{addr}]')
        self.subroutine_stack.append(self.pc + 1)  # Save the return address
        return f'mem[rs + 1] := pc, rs + 1, pc := mem[{addr}]'

##################### RTN RULE########################################## DONE###################
    def apply_rtn_rule(self):
        if not self.subroutine_stack:
            raise ValueError("No return address found on the subroutine stack.")
        
        return_addr = self.old_pc
        self.rules_applied.append(f'Rule: rtn -> pc, rs - 1 := mem[rs], rs - 1, pc := mem[{return_addr}]')
        self.pc = return_addr  # Update the program counter
        return f'pc, rs - 1 := mem[rs], rs - 1, pc := mem[{return_addr}]'
        
##################### halt RULE########################################## DONE###################
    def apply_halt_rule(self):
        self.rules_applied.append(f'Rule: halt -> HALT')
        self.pc += 1  # Increment the program counter
        raise StopIteration('Program halted')

    def apply_loadn_rule(self, num, ri):
        # Verify that num and ri are valid arguments
        if not num.isdigit():
            raise ValueError("Invalid value for num.")
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")

        self.rules_applied.append(f'Rule: loadn {num} {ri} -> {ri} := {num}')
        self.pc += 1  # Increment the program counter
        return f'{ri} := {num}'

    def apply_loadi_rule(self, mem_addr, ri):
        # Verify that mem_addr and ri are valid arguments
        if not mem_addr.isdigit():
            raise ValueError("Invalid value for mem_addr.")
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")

        self.rules_applied.append(f'Rule: loadi {mem_addr} {ri} -> {ri} := mem[mem_addr]')
        self.pc += 1  # Increment the program counter
        return f'{ri} := mem[{mem_addr}]'

    def apply_storer_rule(self, ri, mem_addr):
        # Verify that ri and mem_addr are valid arguments
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        if not mem_addr.isdigit():
            raise ValueError("Invalid value for mem_addr.")

        self.rules_applied.append(f'Rule: storer {ri} {mem_addr} -> mem[mem_addr] := {ri}')
        self.pc += 1  # Increment the program counter
        return f'mem[{mem_addr}] := {ri}'

    def apply_storei_rule(self, ri, mem_addr):
        # Verify that ri and mem_addr are valid arguments
        if not ri.startswith('r') or not ri[1:].isdigit():
            raise ValueError("Invalid register value for ri.")
        if not mem_addr.isdigit():
            raise ValueError("Invalid value for mem_addr.")

        self.rules_applied.append(f'Rule: storei {ri} {mem_addr} -> mem[mem[{mem_addr}]] := {ri}')
        self.pc += 1  # Increment the program counter
        return f'mem[mem[{mem_addr}]] := {ri}'

# Create an instance of ApooInterpreter
interpreter = ApooInterpreter()

# Define a list to store the program interpretations
interpretations = []

# Test the interpret() method with multiple programs
programs = [
    'load 2 r1',
    'load 1 r2',
    'push r10',
    'load 2 r1',
    'load 20 r1',
    'load 30 r2',
    'jsr test',
    'add r2 r1',
    'test: add r1 r2',
    'store r1 5',
    'inc r2',
    'dec r2',
    'push r1',
    'pop r2',
    'jump 20',
    'halt',
    'inc r2',
    'dec r1',
    'rtn'
]

interpretations = []
for program in programs:
    initial_state, final_state, rules_applied, pc = interpreter.interpret(program)
    interpretation = {
        'program': program,
        'initial_state': initial_state,
        'final_state': final_state,
        'rules_applied': rules_applied,
        'pc': pc
    }
    interpretations.append(interpretation)
    if (final_state == "HALT"):
        break

# Print the saved interpretations
for interpretation in interpretations:
    program = interpretation['program']
    initial_state = interpretation['initial_state']
    final_state = interpretation['final_state']
    rules_applied = interpretation['rules_applied']
    pc = interpretation['pc']

    print("\nProgram:", program)
    print("Initial state:", initial_state)
    print("Final state:", final_state)
    print("PC:", pc)

print("\n\nRules applied:")
for rule in rules_applied:
    print(rule)